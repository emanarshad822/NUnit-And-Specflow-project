# NUnit-And-Specflow-project
This repository contains a test automation project demonstrating the use of Cucumber in a BDD-style format with feature files, step definitions, and the implementation of the Page Object Model (POM). 
